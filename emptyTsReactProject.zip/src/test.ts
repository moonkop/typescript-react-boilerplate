let a :number=1011;
console.log(a)
